import React from 'react';
import type { HistoryEntry } from '../types';
import { Icons } from './Icons';

interface HistorySectionProps {
  history: HistoryEntry[];
  onSelect: (id: string) => void;
  onClear: () => void;
  selectedId: string | null;
}

const HistoryItem: React.FC<{
  item: HistoryEntry;
  isSelected: boolean;
  onSelect: (id: string) => void;
}> = ({ item, isSelected, onSelect }) => {
  return (
    <button
      onClick={() => onSelect(item.id)}
      className={`w-full text-left p-3 rounded-lg transition-all duration-200 border ${
        isSelected
          ? 'bg-[rgba(0,246,255,0.15)] border-[var(--glow-cyan)] shadow-md'
          : 'bg-[rgba(15,22,48,0.5)] hover:bg-[rgba(15,22,48,0.9)] hover:border-[var(--hover-border-color)] border-[var(--border-color)]'
      }`}
    >
      <div className="flex items-center gap-4">
        <img 
          src={`data:${item.image.mimeType};base64,${item.image.base64}`} 
          alt={item.medicineName} 
          className="w-12 h-12 rounded-md object-cover bg-gray-800 border border-[var(--border-color)]"
        />
        <div className="flex-grow min-w-0">
          <p className="font-semibold text-gray-200 truncate">{item.medicineName}</p>
          <p className="text-sm text-gray-400">{new Date(item.timestamp).toLocaleString()}</p>
        </div>
        {isSelected && <div className="text-[var(--glow-cyan)]"><Icons.check /></div>}
      </div>
    </button>
  );
};


export const HistorySection: React.FC<HistorySectionProps> = ({ history, onSelect, onClear, selectedId }) => {
  if (history.length === 0) {
    return null;
  }

  return (
    <div className="futuristic-card p-6 md:p-8 animate-fade-in animate-delay-200">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-bold text-white tracking-wide">History</h2>
        <button
          onClick={onClear}
          className="text-sm font-medium text-red-400 hover:text-red-300 transition-colors"
          style={{ textShadow: '0 0 8px rgba(248, 113, 113, 0.5)' }}
          aria-label="Clear all analysis history"
        >
          Clear All
        </button>
      </div>
      <div className="space-y-3 max-h-96 overflow-y-auto pr-2 -mr-2">
        {history.map(item => (
          <HistoryItem
            key={item.id}
            item={item}
            isSelected={item.id === selectedId}
            onSelect={onSelect}
          />
        ))}
      </div>
    </div>
  );
};