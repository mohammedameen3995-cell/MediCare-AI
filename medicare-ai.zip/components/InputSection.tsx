import React from 'react';
import type { UserData, MedicineImage } from '../types';
import { Icons } from './Icons';

interface InputSectionProps {
  userData: UserData;
  setUserData: React.Dispatch<React.SetStateAction<UserData>>;
  image: MedicineImage;
  setImage: React.Dispatch<React.SetStateAction<MedicineImage>>;
}

const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve((reader.result as string).split(',')[1]);
    reader.onerror = (error) => reject(error);
  });
};

const InputField: React.FC<{
  id: keyof UserData;
  label: string;
  placeholder: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
  type?: 'text' | 'number' | 'textarea';
}> = ({ id, label, placeholder, value, onChange, type = 'text' }) => (
  <div>
    <label htmlFor={id} className="block text-sm font-medium text-gray-400 mb-2">
      {label}
    </label>
    {type === 'textarea' ? (
      <textarea
        id={id}
        name={id}
        rows={3}
        className="futuristic-input"
        placeholder={placeholder}
        value={value}
        onChange={onChange}
      />
    ) : (
      <input
        type={type}
        id={id}
        name={id}
        className="futuristic-input"
        placeholder={placeholder}
        value={value}
        onChange={onChange}
      />
    )}
  </div>
);

export const InputSection: React.FC<InputSectionProps> = ({ userData, setUserData, image, setImage }) => {
  
  const handleUserDataChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setUserData(prev => ({ ...prev, [name]: value }));
  };

  const handleImageChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      try {
        const base64 = await fileToBase64(file);
        setImage({ file, base64, mimeType: file.type });
      } catch (error) {
        console.error("Error converting file to base64:", error);
      }
    }
  };

  return (
    <div className="futuristic-card p-6 md:p-8 animate-fade-in">
      <h2 className="text-2xl font-bold text-white mb-6 tracking-wide">Health Profile</h2>
      <form className="space-y-6">
        <fieldset>
          <legend className="text-lg font-semibold text-[var(--glow-cyan)] mb-4 tracking-wider">Vitals</legend>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <InputField id="age" label="Age" placeholder="e.g., 35" value={userData.age} onChange={handleUserDataChange} type="number" />
            <InputField id="heartbeat" label="Heartbeat (BPM)" placeholder="e.g., 72" value={userData.heartbeat} onChange={handleUserDataChange} type="number" />
            <InputField id="bloodPressure" label="Blood Pressure" placeholder="e.g., 120/80" value={userData.bloodPressure} onChange={handleUserDataChange} />
            <InputField id="bloodSugar" label="Blood Sugar (mg/dL)" placeholder="e.g., 90" value={userData.bloodSugar} onChange={handleUserDataChange} type="number" />
          </div>
        </fieldset>
        
        <fieldset>
          <legend className="text-lg font-semibold text-[var(--glow-cyan)] mb-4 tracking-wider">Lifestyle & Symptoms</legend>
          <div className="space-y-6">
            <InputField id="routines" label="Daily Routines" placeholder="e.g., Morning walk, office job" value={userData.routines} onChange={handleUserDataChange} type="textarea" />
            <InputField id="food" label="Recent Food Consumption" placeholder="e.g., Balanced diet, high in fiber" value={userData.food} onChange={handleUserDataChange} type="textarea" />
            <InputField id="symptoms" label="Current Diseases or Symptoms" placeholder="e.g., Hypertension, headaches" value={userData.symptoms} onChange={handleUserDataChange} type="textarea" />
          </div>
        </fieldset>
        
        <fieldset>
          <legend className="text-lg font-semibold text-[var(--glow-cyan)] mb-4 tracking-wider">Medicine</legend>
          <div className="md:col-span-2">
            <div 
              className="mt-1 flex items-center justify-center px-6 pt-5 pb-6 border-2 border-dashed rounded-lg transition-colors"
              style={{ borderColor: 'var(--border-color)' }}
              onMouseOver={(e) => e.currentTarget.style.borderColor = 'var(--hover-border-color)'}
              onMouseOut={(e) => e.currentTarget.style.borderColor = 'var(--border-color)'}
            >
              <div className="space-y-2 text-center">
                  {image.file ? (
                      <img src={URL.createObjectURL(image.file)} alt="Medicine Preview" className="mx-auto h-24 w-auto rounded-md object-contain border border-[var(--border-color)] p-1" />
                  ) : image.base64 ? (
                     <img src={`data:${image.mimeType};base64,${image.base64}`} alt="Medicine Preview" className="mx-auto h-24 w-auto rounded-md object-contain border border-[var(--border-color)] p-1" />
                  ) : (
                      <Icons.upload />
                  )}
                <div className="flex text-sm text-gray-400">
                  <label htmlFor="file-upload" className="relative cursor-pointer bg-transparent rounded-md font-medium text-[var(--glow-cyan)] hover:text-white focus-within:outline-none">
                    <span>Upload file</span>
                    <input id="file-upload" name="file-upload" type="file" className="sr-only" onChange={handleImageChange} accept="image/*" />
                  </label>
                  <p className="pl-1">or drag and drop</p>
                </div>
                <p className="text-xs text-gray-500">PNG, JPG, GIF up to 10MB</p>
              </div>
            </div>
          </div>
        </fieldset>
      </form>
    </div>
  );
};