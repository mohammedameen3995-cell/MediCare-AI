import React, { useState } from 'react';
import { parseAnalysis, ParsedSection } from '../utils/markdownParser';
import { Icons } from './Icons';

const getIconForSection = (title: string) => {
    const lowerTitle = title.toLowerCase();
    if (lowerTitle.includes('dietary')) return <Icons.diet />;
    if (lowerTitle.includes('side effect') || lowerTitle.includes('warning')) return <Icons.warning />;
    if (lowerTitle.includes('usage') || lowerTitle.includes('safe')) return <Icons.usage />;
    if (lowerTitle.includes('risk')) return <Icons.risk />;
    if (lowerTitle.includes('identification') || lowerTitle.includes('explanation')) return <Icons.pill />;
    return <Icons.info />;
};

const SectionCard: React.FC<{ section: ParsedSection, index: number }> = ({ section, index }) => (
    <div className={`p-6 rounded-xl bg-[rgba(15,22,48,0.8)] border border-[var(--border-color)] animate-fade-in`} style={{ animationDelay: `${index * 100}ms` }}>
        <div className="flex items-center gap-4 mb-3">
            <div className="w-10 h-10 flex items-center justify-center rounded-full bg-[rgba(0,246,255,0.1)] text-[var(--glow-cyan)] border border-[var(--border-color)]">
                {getIconForSection(section.title)}
            </div>
            <h3 className="text-lg font-bold text-white tracking-wider">{section.title}</h3>
        </div>
        <div className="pl-14 text-gray-300 whitespace-pre-wrap prose prose-sm max-w-none prose-invert prose-p:text-gray-300 prose-li:text-gray-300">{section.content}</div>
    </div>
);

const SummaryCard: React.FC<{ content: string, index: number }> = ({ content, index }) => (
    <div className={`mt-6 p-6 rounded-xl border border-[var(--glow-cyan)] shadow-lg animate-fade-in`} style={{ animationDelay: `${index * 100}ms`, background: 'linear-gradient(135deg, rgba(0, 246, 255, 0.05), rgba(0, 246, 255, 0.15))' }}>
        <div className="whitespace-pre-wrap text-white prose prose-sm max-w-none prose-invert prose-p:text-white prose-li:text-white" dangerouslySetInnerHTML={{ __html: content.replace(/(?:###|#)\s*(.*)/g, '<div class="flex items-center gap-4 mb-4"><div class="w-10 h-10 flex items-center justify-center rounded-full bg-[rgba(0,246,255,0.2)] text-[var(--glow-cyan)] border border-[var(--border-color)]">' + Icons.summarySvg + '</div><h3 class="text-xl font-bold text-[var(--glow-cyan)] tracking-wider">$1</h3></div>').replace(/\*\*(.*?):\*\*/g, '<strong class="text-gray-300">$1:</strong>').replace(/-\s/g, '• ') }}>
        </div>
    </div>
);

const Placeholder: React.FC = () => (
    <div className="futuristic-card p-6 md:p-8 text-center flex flex-col justify-center items-center min-h-[500px] animate-fade-in">
        <Icons.placeholder />
        <h3 className="text-2xl font-bold text-white mt-6 mb-2 tracking-wide">Awaiting Analysis</h3>
        <p className="text-gray-400 max-w-md">Input your health profile, upload a medicine image, and initiate the AI analysis for personalized guidance.</p>
    </div>
);

const ErrorDisplay: React.FC<{ error: string }> = ({ error }) => (
    <div className="futuristic-card p-6 rounded-xl shadow-lg border border-red-500/50 animate-fade-in bg-red-900/20">
        <div className="flex items-center gap-4 mb-3">
            <div className="w-10 h-10 flex items-center justify-center rounded-full bg-red-500/10 text-red-400 border border-red-500/30">
                <Icons.error />
            </div>
            <h3 className="text-xl font-bold text-red-300 tracking-wider">Analysis Error</h3>
        </div>
        <p className="pl-14 text-red-300 whitespace-pre-wrap">{error}</p>
    </div>
);

interface AnalysisDisplayProps {
  analysis: string;
  error: string | null;
  isTranslating: boolean;
  selectedLanguage: string;
  onLanguageChange: (lang: string) => void;
  isPlaying: boolean;
  isGeneratingSpeech: boolean;
  onPlayPause: () => void;
  selectedVoice: string;
  onVoiceChange: (voice: string) => void;
}

const languages = [
    { code: 'en', name: 'English' },
    { code: 'ta', name: 'Tamil' },
    { code: 'hi', name: 'Hindi' },
    { code: 'ml', name: 'Malayalam' },
    { code: 'kn', name: 'Kannada' },
];

const voices = ['Zephyr', 'Kore', 'Puck', 'Charon', 'Fenrir'];

// Fix: Removed `speechRate` and `onRateChange` props as they are no longer used.
export const AnalysisDisplay: React.FC<AnalysisDisplayProps> = ({ 
    analysis, error, isTranslating, selectedLanguage, onLanguageChange,
    isPlaying, isGeneratingSpeech, onPlayPause,
    selectedVoice, onVoiceChange
}) => {
  const [showSettings, setShowSettings] = useState(false);

  if (error) {
    return <ErrorDisplay error={error} />;
  }

  if (!analysis) {
    return <Placeholder />;
  }

  const [mainContent, summaryCardContent] = analysis.split('---');
  const parsedSections = parseAnalysis(mainContent);
  const isSpeechDisabled = selectedLanguage !== 'en' || isGeneratingSpeech;

  return (
    <div className="futuristic-card p-6 md:p-8 relative">
       {isTranslating && (
        <div className="absolute inset-0 bg-[rgba(10,15,31,0.8)] backdrop-blur-sm flex items-center justify-center z-20 rounded-2xl">
          <div className="text-center">
             <div className="w-8 h-8 rounded-full animate-spin border-4 border-dashed border-[var(--glow-cyan)] border-t-transparent mx-auto"></div>
             <p className="text-lg text-[var(--glow-cyan)] mt-3">Translating...</p>
          </div>
        </div>
      )}

      <div className="flex justify-between items-center mb-6 animate-fade-in flex-wrap gap-4">
        <h2 className="text-2xl font-bold text-white tracking-wide">AI Health Analysis</h2>
        <div className="flex items-center gap-2">
            <select
                value={selectedLanguage}
                onChange={(e) => onLanguageChange(e.target.value)}
                className="futuristic-input !w-auto !py-2 !px-3 text-sm"
                aria-label="Select language"
            >
                {languages.map(lang => (
                    <option key={lang.code} value={lang.code}>{lang.name}</option>
                ))}
            </select>
            <div className="relative">
                <button
                    onClick={onPlayPause}
                    disabled={isSpeechDisabled}
                    className="p-2 rounded-md transition-colors text-gray-300 border border-transparent disabled:opacity-50 disabled:cursor-not-allowed hover:bg-[rgba(0,246,255,0.1)] hover:text-white hover:border-[var(--border-color)]"
                    aria-label={isPlaying ? "Stop reading aloud" : "Read analysis aloud"}
                    title={selectedLanguage !== 'en' ? "Voice output is only available in English" : (isPlaying ? "Stop Reading" : "Read Aloud")}
                >
                    {isGeneratingSpeech ? (
                        <div className="w-6 h-6 rounded-full animate-spin border-2 border-dashed border-[var(--glow-cyan)] border-t-transparent"></div>
                    ) : (
                        <Icons.speaker isPlaying={isPlaying} />
                    )}
                </button>
            </div>
             <div className="relative">
                <button
                    onClick={() => setShowSettings(s => !s)}
                    disabled={selectedLanguage !== 'en'}
                    className="p-2 rounded-md transition-colors text-gray-300 border border-transparent disabled:opacity-50 disabled:cursor-not-allowed hover:bg-[rgba(0,246,255,0.1)] hover:text-white hover:border-[var(--border-color)]"
                    aria-label="Open speech settings"
                    title={selectedLanguage !== 'en' ? "Settings only available in English" : "Speech Settings"}
                >
                    <Icons.settings />
                </button>
                {showSettings && selectedLanguage === 'en' && (
                    <div className="absolute right-0 top-full mt-2 w-64 futuristic-card p-4 z-10 animate-fade-in">
                        <div className="space-y-4">
                            <div>
                                <label htmlFor="voice-select" className="block text-sm font-medium text-gray-400 mb-1">Voice</label>
                                <select id="voice-select" value={selectedVoice} onChange={e => onVoiceChange(e.target.value)} className="futuristic-input !py-1.5 w-full">
                                    {voices.map(v => <option key={v} value={v}>{v}</option>)}
                                </select>
                            </div>
                        </div>
                    </div>
                )}
            </div>
        </div>
      </div>
      
      <div className="space-y-4">
          {parsedSections.map((section, index) => (
              <SectionCard key={index} section={section} index={index} />
          ))}
      </div>

      {summaryCardContent && (
        <SummaryCard content={summaryCardContent} index={parsedSections.length} />
      )}
    </div>
  );
};
