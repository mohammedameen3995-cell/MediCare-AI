import React from 'react';

const speaker = ({ isPlaying }: { isPlaying: boolean }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
        {isPlaying ? (
            // A clear "Stop" icon for when audio is playing
            <path strokeLinecap="round" strokeLinejoin="round" d="M5.25 7.5A2.25 2.25 0 017.5 5.25h9a2.25 2.25 0 012.25 2.25v9a2.25 2.25 0 01-2.25 2.25h-9a2.25 2.25 0 01-2.25-2.25v-9z" />
        ) : (
            // An intuitive "Speaker Wave" icon to indicate audio can be played
            <>
                <path strokeLinecap="round" strokeLinejoin="round" d="M5.25 7.5H9.75l4.5-4.5v18l-4.5-4.5H5.25a2.25 2.25 0 01-2.25-2.25v-9a2.25 2.25 0 012.25-2.25z" />
                <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 12c0-1.99.9-3.83 2.34-5.01m0 10.02A8.25 8.25 0 0016.5 12z" />
            </>
        )}
    </svg>
);

const diet = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M21 15.26c-1.06.39-2.2.59-3.38.59-2.67 0-5.13-1.04-6.94-2.9l-.47-.47c-1.8-1.87-4.27-2.9-6.94-2.9-1.18 0-2.32.2-3.38.59" /><path strokeLinecap="round" strokeLinejoin="round" d="M21 15.26c1.06-.39 1.9-1.29 1.9-2.42 0-1.42-1.15-2.57-2.57-2.57-1.03 0-1.9.6-2.33 1.44" /><path strokeLinecap="round" strokeLinejoin="round" d="M3 9.74C1.94 9.35 1.1 8.45 1.1 7.32c0-1.42 1.15-2.57 2.57-2.57 1.03 0 1.9.6 2.33 1.44" /></svg>;
const warning = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z" /></svg>;
const usage = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>;
const risk = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M11.25 11.25l.041-.02a.75.75 0 011.063.852l-.708 2.836a.75.75 0 001.063.853l.041-.021M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-9-3.75h.008v.008H12V8.25z" /></svg>;
const pill = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M6.75 12.75l-1.335-1.336a6 6 0 118.49-8.489l1.336 1.335-8.49 8.489z" /><path strokeLinecap="round" strokeLinejoin="round" d="M9 12l6-6" /></svg>;
const info = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M11.25 11.25l.041-.02a.75.75 0 011.063.852l-.708 2.836a.75.75 0 001.063.853l.041-.021M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-9-3.75h.008v.008H12V8.25z" /></svg>;

const placeholder = () => <svg className="w-40 h-40 text-gray-700" viewBox="0 0 120 120" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M60 110C87.6142 110 110 87.6142 110 60C110 32.3858 87.6142 10 60 10C32.3858 10 10 32.3858 10 60C10 87.6142 32.3858 110 60 110Z" stroke="currentColor" strokeOpacity="0.3" strokeWidth="4"/><path d="M40 60C40 48.9543 48.9543 40 60 40C71.0457 40 80 48.9543 80 60" stroke="var(--glow-cyan)" strokeOpacity="0.5" strokeWidth="4" strokeLinecap="round" strokeDasharray="4 12" /><path d="M60 40V80M40 60H80" stroke="currentColor" strokeOpacity="0.2" strokeWidth="2"/><rect x="52.5" y="52.5" width="15" height="15" rx="7.5" fill="var(--glow-cyan)" fillOpacity="0.1" /><rect x="52.5" y="52.5" width="15" height="15" rx="7.5" stroke="var(--glow-cyan)" strokeOpacity="0.7" strokeWidth="2" /></svg>;
const error = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z" /></svg>;
const logo = () => <svg className="w-7 h-7" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4 11h-3v3h-2v-3H8v-2h3V8h2v3h3v2z"/></svg>;
const check = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" /></svg>;
const summarySvg = '<svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5"><path stroke-linecap="round" stroke-linejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>';
const upload = () => <svg className="mx-auto h-12 w-12 text-gray-600" fill="none" viewBox="0 0 48 48" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M3 15a2 2 0 012-2h38a2 2 0 012 2v18a2 2 0 01-2 2H5a2 2 0 01-2-2V15z" /><path strokeLinecap="round" strokeLinejoin="round" d="M12 21v6m6-6v6m6-6v6" /><path strokeLinecap="round" strokeLinejoin="round" d="M21 21a3 3 0 11-6 0 3 3 0 016 0z" /><path d="M45 24h-3M6 24H3" strokeLinecap="round" strokeLinejoin="round" /></svg>
const settings = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" /><path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /></svg>;


export const Icons = {
    speaker,
    diet,
    warning,
    usage,
    risk,
    pill,
    info,
    placeholder,
    error,
    logo,
    check,
    summarySvg,
    upload,
    settings
};