import React, { useState, useEffect, useCallback, useRef } from 'react';
import { InputSection } from './components/InputSection';
import { AnalysisDisplay } from './components/AnalysisDisplay';
import { HistorySection } from './components/HistorySection';
import { analyzeHealthData, generateSpeech, translateText } from './services/geminiService';
import { extractMedicineName } from './utils/markdownParser';
import type { UserData, MedicineImage, HistoryEntry } from './types';
import { Icons } from './components/Icons';
import { decode, decodeAudioData } from './utils/audioUtils';


const Header = () => (
  <header className="py-6">
    <div className="text-center">
      <div className="flex items-center justify-center gap-3">
         <div className="w-12 h-12 text-white bg-[rgba(0,246,255,0.1)] rounded-full flex items-center justify-center shadow-lg border border-[var(--border-color)]">
            <Icons.logo />
         </div>
        <h1 className="text-4xl font-bold text-white tracking-wider">
          MediCare <span className="text-[var(--glow-cyan)]" style={{ textShadow: '0 0 10px var(--glow-cyan)' }}>AI</span>
        </h1>
      </div>
      <p className="mt-3 text-lg text-gray-400">Your Personal AI Healthcare Assistant</p>
    </div>
  </header>
);

const Spinner = () => (
  <div className="flex items-center justify-center space-x-2">
    <div className="w-4 h-4 rounded-full animate-pulse bg-[var(--glow-cyan)]"></div>
    <div className="w-4 h-4 rounded-full animate-pulse bg-[var(--glow-cyan)]" style={{ animationDelay: '0.2s' }}></div>
    <div className="w-4 h-4 rounded-full animate-pulse bg-[var(--glow-cyan)]" style={{ animationDelay: '0.4s' }}></div>
  </div>
);

const App: React.FC = () => {
  const [userData, setUserData] = useState<UserData>({
    age: '',
    heartbeat: '',
    bloodPressure: '',
    bloodSugar: '',
    routines: '',
    food: '',
    symptoms: '',
  });

  const [image, setImage] = useState<MedicineImage>({
    file: null,
    base64: '',
    mimeType: '',
  });

  const [originalAnalysis, setOriginalAnalysis] = useState<string>('');
  const [displayedAnalysis, setDisplayedAnalysis] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [loadingMessage, setLoadingMessage] = useState<string>('');
  const [error, setError] = useState<string | null>(null);

  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [selectedHistoryId, setSelectedHistoryId] = useState<string | null>(null);

  // Translation state
  const [selectedLanguage, setSelectedLanguage] = useState<string>('en');
  const [isTranslating, setIsTranslating] = useState<boolean>(false);

  // Text-to-speech state
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [isGeneratingSpeech, setIsGeneratingSpeech] = useState<boolean>(false);
  const [selectedVoice, setSelectedVoice] = useState<string>('Zephyr');

  const audioContextRef = useRef<AudioContext | null>(null);
  const audioSourceRef = useRef<AudioBufferSourceNode | null>(null);

  useEffect(() => {
    // Initialize AudioContext on client-side
    // Fix: Cast window to any to support webkitAudioContext for older browsers without TypeScript errors.
    audioContextRef.current = new ((window as any).AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
  }, []);

  const loadingMessages = [
    "Initializing AI analysis...",
    "Analyzing your health profile...",
    "Identifying medicine from image...",
    "Cross-referencing with medical databases...",
    "Formulating personalized guidance...",
    "Finalizing your report..."
  ];

  useEffect(() => {
    try {
      const storedHistory = localStorage.getItem('medicare-ai-history');
      if (storedHistory) {
        setHistory(JSON.parse(storedHistory));
      }
    } catch (e) {
      console.error("Failed to parse history from localStorage", e);
      localStorage.removeItem('medicare-ai-history');
    }
  }, []);

  useEffect(() => {
    if (history.length > 0) {
        localStorage.setItem('medicare-ai-history', JSON.stringify(history));
    } else {
        localStorage.removeItem('medicare-ai-history');
    }
  }, [history]);

  useEffect(() => {
    let interval: number;
    if (isLoading) {
      let i = 0;
      setLoadingMessage(loadingMessages[i]);
      interval = window.setInterval(() => {
        i = (i + 1) % loadingMessages.length;
        setLoadingMessage(loadingMessages[i]);
      }, 2500);
    }
    return () => {
      if(interval) clearInterval(interval);
    };
  }, [isLoading, loadingMessages]);

  const handleStopAudio = useCallback(() => {
    if (audioSourceRef.current) {
        audioSourceRef.current.stop();
        audioSourceRef.current.disconnect();
        audioSourceRef.current = null;
    }
    setIsPlaying(false);
  }, []);

  const handlePlayPause = useCallback(async () => {
    if (isPlaying) {
        handleStopAudio();
        return;
    }
    
    if (!originalAnalysis || !audioContextRef.current) return;
    
    setIsGeneratingSpeech(true);
    setError(null);
    try {
        const textToSpeak = originalAnalysis.split('---')[0]; // Only speak the main content
        // Fix: Removed speechRate argument as it's not a supported parameter.
        const base64Audio = await generateSpeech(textToSpeak, selectedVoice);
        const audioData = decode(base64Audio);
        const audioBuffer = await decodeAudioData(audioData, audioContextRef.current, 24000, 1);

        const source = audioContextRef.current.createBufferSource();
        source.buffer = audioBuffer;
        source.connect(audioContextRef.current.destination);
        source.start();

        source.onended = () => {
            setIsPlaying(false);
            audioSourceRef.current = null;
        };

        audioSourceRef.current = source;
        setIsPlaying(true);
    } catch (err: any) {
        setError(err.message || "Failed to play audio.");
        setIsPlaying(false);
    } finally {
        setIsGeneratingSpeech(false);
    }
  }, [isPlaying, originalAnalysis, selectedVoice, handleStopAudio]);

  const handleSubmit = useCallback(async () => {
    if (!image.base64) {
      setError("Please upload an image of your medicine.");
      return;
    }
    setError(null);
    setIsLoading(true);
    setDisplayedAnalysis('');
    setOriginalAnalysis('');
    setSelectedHistoryId(null);
    setSelectedLanguage('en');
    handleStopAudio();

    try {
      const result = await analyzeHealthData(userData, image);
      setOriginalAnalysis(result);
      setDisplayedAnalysis(result);
      
      const [, summaryCardContent] = result.split('---');
      const newHistoryEntry: HistoryEntry = {
        id: new Date().toISOString(),
        timestamp: new Date().toISOString(),
        userData,
        image: { ...image, file: null }, 
        analysis: result,
        medicineName: summaryCardContent ? extractMedicineName(summaryCardContent) : 'Analysis Result'
      };
      setHistory(prev => [newHistoryEntry, ...prev]);

    } catch (err: any) {
      setError(err.message || "An unknown error occurred.");
      setOriginalAnalysis('');
      setDisplayedAnalysis('');
    } finally {
      setIsLoading(false);
    }
  }, [userData, image, handleStopAudio]);

  const handleSelectHistory = (id: string) => {
    const entry = history.find(h => h.id === id);
    if (entry) {
        setSelectedHistoryId(id);
        setUserData(entry.userData);
        setImage(entry.image);
        setOriginalAnalysis(entry.analysis);
        setDisplayedAnalysis(entry.analysis);
        setSelectedLanguage('en');
        setError(null);
        handleStopAudio();
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleClearHistory = () => {
    if(window.confirm("Are you sure you want to clear all history? This cannot be undone.")) {
        setHistory([]);
        localStorage.removeItem('medicare-ai-history');
    }
  };

  const handleLanguageChange = async (lang: string) => {
    setSelectedLanguage(lang);
    handleStopAudio();

    if (lang === 'en') {
        setDisplayedAnalysis(originalAnalysis);
        return;
    }

    if (!originalAnalysis) return;

    setIsTranslating(true);
    setError(null);
    try {
        const translatedText = await translateText(originalAnalysis, lang);
        setDisplayedAnalysis(translatedText);
    } catch (err: any) {
        setError(err.message || "Translation failed.");
        setDisplayedAnalysis(originalAnalysis); // Revert on failure
        setSelectedLanguage('en');
    } finally {
        setIsTranslating(false);
    }
  };


  const isFormIncomplete = Object.values(userData).some(val => typeof val === 'string' && val.trim() === '') || !image.base64;

  return (
    <div className="min-h-screen">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        <Header />
        <main className="mt-8 grid grid-cols-1 lg:grid-cols-5 gap-8">
          <div className="lg:col-span-2 space-y-8">
            <InputSection 
              userData={userData} 
              setUserData={setUserData}
              image={image}
              setImage={setImage}
            />
            <HistorySection 
              history={history}
              onSelect={handleSelectHistory}
              onClear={handleClearHistory}
              selectedId={selectedHistoryId}
            />
          </div>
          
          <div className="lg:col-span-3">
             <AnalysisDisplay 
                analysis={displayedAnalysis} 
                error={error}
                isTranslating={isTranslating}
                selectedLanguage={selectedLanguage}
                onLanguageChange={handleLanguageChange}
                isPlaying={isPlaying}
                isGeneratingSpeech={isGeneratingSpeech}
                onPlayPause={handlePlayPause}
                selectedVoice={selectedVoice}
                onVoiceChange={setSelectedVoice}
             />
          </div>
        </main>
      </div>
      <div className="sticky bottom-0 w-full bg-[rgba(10,15,31,0.8)] backdrop-blur-md border-t border-[var(--border-color)] p-4">
        <div className="container mx-auto max-w-4xl flex items-center justify-center">
            {isLoading ? (
                <div className="text-center">
                    <Spinner />
                    <p className="text-sm text-[var(--glow-cyan)] mt-2 font-medium tracking-wider">{loadingMessage}</p>
                </div>
            ) : (
                 <button
                    onClick={handleSubmit}
                    disabled={isFormIncomplete || isLoading}
                    className="futuristic-btn w-full md:w-auto md:min-w-[300px]"
                >
                    Analyze My Health
                </button>
            )}
        </div>
      </div>
    </div>
  );
};

export default App;
