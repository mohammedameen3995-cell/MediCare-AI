import { GoogleGenAI, Modality } from "@google/genai";
import type { UserData, MedicineImage } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const generatePrompt = (userData: UserData): string => {
  return `
You are a professional healthcare assistant AI integrated in a web application called MediCare AI. Your job is to analyze user health data and medicine information to provide comprehensive and personalized guidance. Your tone must be accurate, clear, and compassionate.

A user has submitted their health details and an image of their medicine. Please perform the following steps, providing as much detail as possible in each section:

1.  **Medicine Identification:** From the provided image, identify the medicine's name, brand (if visible), and its active chemical composition.
2.  **Medicine Explanation:** Provide a very detailed explanation of this medicine. Cover its mechanism of action (how it works in the body), what it is generally used for, common off-label uses if any, the typical age group it's prescribed for, and standard dosage recommendations. Mention if it's a common over-the-counter or prescription-only drug.
3.  **User Data Analysis:** Analyze the following user data:
    - Age: ${userData.age || 'Not provided'}
    - Heartbeat: ${userData.heartbeat || 'Not provided'} BPM
    - Blood Pressure: ${userData.bloodPressure || 'Not provided'}
    - Blood Sugar: ${userData.bloodSugar || 'Not provided'} mg/dL
    - Daily Routines: ${userData.routines || 'Not provided'}
    - Food Consumption: ${userData.food || 'Not provided'}
    - Known Diseases/Symptoms: ${userData.symptoms || 'Not provided'}
4.  **Personalized Guidance:** Based on the user's specific body conditions and the medicine's properties, provide the following in extensive detail. Use clear headings for each section.
    - **Safe Usage:** Suggest the safest way and time for this user to take the medicine (e.g., with food, before bed, with plenty of water). Explain *why* these suggestions are made (e.g., to prevent stomach upset, to improve absorption).
    - **Dietary Recommendations:** Provide a detailed food and diet plan. Include a list of "Foods to Eat," "Foods to Avoid," and explain the reasoning behind these recommendations in relation to the medicine and the user's condition. Offer a sample daily meal plan (Breakfast, Lunch, Dinner, Snacks).
    - **Side Effects & Warnings:** Clearly list potential side effects, separating them into "Common" and "Less Common/Rare" categories. Give specific, actionable warnings if the user is a blood pressure, a blood sugar, or heart patient, or if they might be pregnant. Explain what to do if a side effect occurs. Use simple, non-technical language.
    - **Risk Assessment:** If you identify any potential mismatch, significant risk, or contraindication between the medicine and the user's health profile (e.g., age, existing conditions), gently but clearly warn the user. Explain the potential interaction and strongly recommend consulting a doctor immediately before taking the medicine.
5.  **Summary Card:** Conclude your entire response with a "Summary Card". This section must be clearly demarcated with a line of '---'. Format it exactly as follows:

---

### Summary Card

-   **Medicine Name:** [Identified Medicine Name]
-   **Purpose:** [Brief purpose]
-   **Dosage Instruction:** [Personalized dosage advice]
-   **User Safety:** [State "Appears Safe" or "Potential Risk Found". Add a brief reason.]
-   **Food & Lifestyle Advice:** [One-sentence summary of diet advice]
-   **Doctor Recommendation:** [State "Consult a doctor for confirmation" or "Immediate consultation recommended" if risks were found.]

**Disclaimer:** Always remind the user that you are an AI assistant and this advice is not a substitute for professional medical consultation. Place this disclaimer at the very end of your response, after the summary card.
  `;
};

export const analyzeHealthData = async (userData: UserData, image: MedicineImage): Promise<string> => {
  if (!image.base64 || !image.mimeType) {
    throw new Error("Medicine image is required for analysis.");
  }

  const textPart = {
    text: generatePrompt(userData),
  };

  const imagePart = {
    inlineData: {
      mimeType: image.mimeType,
      data: image.base64,
    },
  };

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: { parts: [textPart, imagePart] },
    });
    return response.text;
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    throw new Error("Failed to get analysis from AI. Please check your connection and try again.");
  }
};

// Fix: Removed `rate` parameter as it's not supported by the Gemini API speechConfig.
export const generateSpeech = async (text: string, voice: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-preview-tts',
      contents: [{ parts: [{ text }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: voice },
            },
        },
      },
    });
    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (!base64Audio) {
      throw new Error("No audio data received from API.");
    }
    return base64Audio;
  } catch(error) {
    console.error("Error generating speech:", error);
    throw new Error("Failed to generate audio for the analysis.");
  }
};

export const translateText = async (text: string, targetLanguage: string): Promise<string> => {
  const prompt = `Translate the following medical analysis into ${targetLanguage}. Keep the original formatting, including markdown like headings, lists, and bold text. Do not add any extra text or disclaimers.

---
${text}
---
`;
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error("Error translating text:", error);
    throw new Error(`Failed to translate text to ${targetLanguage}.`);
  }
};
