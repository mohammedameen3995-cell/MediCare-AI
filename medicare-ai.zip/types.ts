export interface UserData {
  age: string;
  heartbeat: string;
  bloodPressure: string;
  bloodSugar: string;
  routines: string;
  food: string;
  symptoms: string;
}

export interface MedicineImage {
  file: File | null;
  base64: string;
  mimeType: string;
}

export interface HistoryEntry {
  id: string;
  timestamp: string;
  userData: UserData;
  image: MedicineImage;
  analysis: string;
  medicineName: string;
}
