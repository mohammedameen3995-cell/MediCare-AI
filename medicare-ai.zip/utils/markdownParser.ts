export interface ParsedSection {
  title: string;
  content: string;
}

export const parseAnalysis = (analysisText: string): ParsedSection[] => {
  if (!analysisText) return [];

  const sections: ParsedSection[] = [];
  // Clean up leading/trailing whitespace and newlines
  const cleanedText = analysisText.trim();
  
  // Split by markdown bold headings like **Title:**
  // This regex looks for a newline, optional whitespace, then **, captures the title, and ends with **
  const parts = cleanedText.split(/\n\s*\*\*(.*?):\*\*/);
  
  // The first part of the split is the content before the first heading
  const introContent = parts.shift()?.trim();
  if (introContent) {
    sections.push({ title: "Medicine Identification & Explanation", content: introContent });
  }

  // The remaining parts are alternating titles and content
  for (let i = 0; i < parts.length; i += 2) {
    const title = parts[i]?.trim();
    const content = parts[i + 1]?.trim();
    if (title && content) {
      sections.push({ title, content });
    }
  }
  
  // A simple fallback if the split doesn't work well
  if (sections.length <= 1 && cleanedText.includes('\n\n')) {
      const fallbackSections = cleanedText.split('\n\n').map(p => p.trim()).filter(Boolean);
      if (fallbackSections.length > 1) {
          return fallbackSections.map((content, index) => ({
              title: `Section ${index + 1}`,
              content
          }));
      }
  }

  return sections;
};

export const extractMedicineName = (summaryCardContent: string): string => {
    const match = summaryCardContent.match(/-\s+\*\*Medicine Name:\*\*\s+(.*)/);
    return match ? match[1].trim() : "Unknown Medicine";
}
